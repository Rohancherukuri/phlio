// Phlio Studio — the project model behind the CapCut-style DM editor.
//
// A project is a main track of clips (photos/videos), overlays (text and
// stickers) and audio items (music, extracted audio, voiceovers). Colour
// filters and adjustments are folded into one 3x4 affine colour matrix that
// is used for the on-device preview (ColorFilter.matrix) *and* sent to the
// server renderer (colorchannelmixer + lutrgb), so what you see is what you
// export.

import 'dart:convert';
import 'dart:math' as math;

int _seq = 0;
String studioId() =>
    '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${(_seq++).toRadixString(36)}';

double _d(Object? v, [double fallback = 0]) =>
    v is num ? v.toDouble() : fallback;

// -- clips -----------------------------------------------------------------------

class StudioClip {
  StudioClip({
    required this.path,
    required this.name,
    required this.kind,
    required this.sourceDuration,
    String? id,
    this.start = 0,
    double? end,
    this.fileId,
  })  : id = id ?? studioId(),
        end = end ?? sourceDuration;

  final String id;
  String path, name;
  String kind; // video | image
  double sourceDuration;
  double start, end;
  double speed = 1, volume = 1;
  int turns = 0;
  bool flip = false, flipV = false, reverse = false;
  double? hold; // freeze frame: seconds held
  List<double>? crop; // x, y, w, h (0-1) after rotation/flip
  String filter = 'none';
  double filterAmount = 1;
  Map<String, double> adjust = {};
  String effect = 'none';
  String fit = 'fill';
  double zoom = 1, panX = 0, panY = 0;
  String motion = 'none', animIn = 'none', animOut = 'none';
  double fadeAudioIn = 0, fadeAudioOut = 0;
  String transition = 'none';
  double transitionDuration = .5;
  String? fileId;

  bool get isPhoto => kind == 'image' || hold != null;
  double get length => hold ?? math.max(.3, (end - start) / speed);

  /// Source time shown at [local] seconds into the clip.
  double sourceAt(double local) {
    if (hold != null) return start;
    final s = (local * speed).clamp(0.0, end - start);
    return reverse ? end - s : start + s;
  }

  List<double> get colorMatrix =>
      studioColorMatrix(filter, filterAmount, adjust);

  Map<String, dynamic> toJson() => {
        'id': id,
        'path': path,
        'name': name,
        'kind': kind,
        'sourceDuration': sourceDuration,
        'start': start,
        'end': end,
        'speed': speed,
        'volume': volume,
        'turns': turns,
        'flip': flip,
        'flipV': flipV,
        'reverse': reverse,
        'hold': hold,
        'crop': crop,
        'filter': filter,
        'filterAmount': filterAmount,
        'adjust': adjust,
        'effect': effect,
        'fit': fit,
        'zoom': zoom,
        'panX': panX,
        'panY': panY,
        'motion': motion,
        'animIn': animIn,
        'animOut': animOut,
        'fadeAudioIn': fadeAudioIn,
        'fadeAudioOut': fadeAudioOut,
        'transition': transition,
        'transitionDuration': transitionDuration,
        'fileId': fileId,
      };

  static StudioClip fromJson(Map j) => StudioClip(
        id: j['id'] as String,
        path: j['path'] as String,
        name: j['name'] as String,
        kind: j['kind'] as String,
        sourceDuration: _d(j['sourceDuration'], 3),
        start: _d(j['start']),
        end: _d(j['end'], 3),
        fileId: j['fileId'] as String?,
      )
        ..speed = _d(j['speed'], 1)
        ..volume = _d(j['volume'], 1)
        ..turns = (j['turns'] as num?)?.toInt() ?? 0
        ..flip = j['flip'] == true
        ..flipV = j['flipV'] == true
        ..reverse = j['reverse'] == true
        ..hold = (j['hold'] as num?)?.toDouble()
        ..crop = (j['crop'] as List?)?.map((e) => _d(e)).toList()
        ..filter = j['filter'] as String? ?? 'none'
        ..filterAmount = _d(j['filterAmount'], 1)
        ..adjust = {
          for (final e in ((j['adjust'] as Map?) ?? const {}).entries)
            e.key.toString(): _d(e.value)
        }
        ..effect = j['effect'] as String? ?? 'none'
        ..fit = j['fit'] as String? ?? 'fill'
        ..zoom = _d(j['zoom'], 1)
        ..panX = _d(j['panX'])
        ..panY = _d(j['panY'])
        ..motion = j['motion'] as String? ?? 'none'
        ..animIn = j['animIn'] as String? ?? 'none'
        ..animOut = j['animOut'] as String? ?? 'none'
        ..fadeAudioIn = _d(j['fadeAudioIn'])
        ..fadeAudioOut = _d(j['fadeAudioOut'])
        ..transition = j['transition'] as String? ?? 'none'
        ..transitionDuration = _d(j['transitionDuration'], .5);

  StudioClip duplicate() => fromJson({...toJson(), 'id': studioId()});

  /// Server render spec.
  Map<String, dynamic> plan() {
    final m = colorMatrix;
    final identity = _isIdentity(m);
    return {
      'file_id': fileId,
      'start': double.parse(start.toStringAsFixed(3)),
      'end': double.parse(end.toStringAsFixed(3)),
      'speed': speed,
      'volume': volume,
      'turns': turns,
      'flip': flip,
      'flip_v': flipV,
      'reverse': reverse && !isPhoto,
      if (hold != null) 'hold': hold,
      if (crop != null) 'crop': crop,
      if (!identity) 'color': m,
      'vignette': (adjust['vignette'] ?? 0).clamp(0.0, 1.0),
      'sharpen': (adjust['sharpen'] ?? 0).clamp(0.0, 1.0),
      'grain': (adjust['grain'] ?? 0).clamp(0.0, 1.0),
      'effect': effect,
      'fit': fit,
      'zoom': zoom,
      'pan_x': panX,
      'pan_y': panY,
      'motion': motion,
      'anim_in': animIn,
      'anim_out': animOut,
      'fade_audio_in': fadeAudioIn,
      'fade_audio_out': fadeAudioOut,
      'transition': transition,
      'transition_duration': transitionDuration,
    };
  }
}

// -- overlays (text + stickers) ----------------------------------------------------------

class StudioOverlay {
  StudioOverlay({
    required this.kind,
    String? id,
    this.text = '',
    this.sticker,
    this.asset,
    this.x = .5,
    this.y = .45,
    this.size = .08,
    this.rotation = 0,
    this.start = 0,
    this.end = 3,
  }) : id = id ?? studioId();

  final String id;
  String kind; // text | sticker
  String text;
  String? sticker; // emoji
  String? asset; // bundled Foxy sticker
  double x, y; // centre, fraction of the canvas
  double size; // text: font size / canvas width; sticker: width / canvas width
  double rotation; // radians
  double start, end;
  String font = 'Manrope';
  int color = 0xFFFFFFFF;
  int accent = 0xFF8D78FF; // box / outline / glow colour
  String style = 'shadow'; // plain | shadow | box | outline | neon | gradient
  String align = 'center';
  bool bold = true;
  String animIn = 'fade', animOut = 'fade';
  String? fileId; // uploaded PNG at export

  String get label => kind == 'text'
      ? (text.isEmpty ? 'Text' : text.replaceAll('\n', ' '))
      : (sticker ?? 'Sticker');

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind,
        'text': text,
        'sticker': sticker,
        'asset': asset,
        'x': x,
        'y': y,
        'size': size,
        'rotation': rotation,
        'start': start,
        'end': end,
        'font': font,
        'color': color,
        'accent': accent,
        'style': style,
        'align': align,
        'bold': bold,
        'animIn': animIn,
        'animOut': animOut,
      };

  static StudioOverlay fromJson(Map j) => StudioOverlay(
        kind: j['kind'] as String,
        id: j['id'] as String,
        text: j['text'] as String? ?? '',
        sticker: j['sticker'] as String?,
        asset: j['asset'] as String?,
        x: _d(j['x'], .5),
        y: _d(j['y'], .5),
        size: _d(j['size'], .08),
        rotation: _d(j['rotation']),
        start: _d(j['start']),
        end: _d(j['end'], 3),
      )
        ..font = j['font'] as String? ?? 'Manrope'
        ..color = (j['color'] as num?)?.toInt() ?? 0xFFFFFFFF
        ..accent = (j['accent'] as num?)?.toInt() ?? 0xFF8D78FF
        ..style = j['style'] as String? ?? 'shadow'
        ..align = j['align'] as String? ?? 'center'
        ..bold = j['bold'] != false
        ..animIn = j['animIn'] as String? ?? 'fade'
        ..animOut = j['animOut'] as String? ?? 'fade';

  StudioOverlay duplicate() =>
      fromJson({...toJson(), 'id': studioId(), 'x': x + .04, 'y': y + .04});
}

// -- audio ---------------------------------------------------------------------------

class StudioAudio {
  StudioAudio({
    required this.kind,
    required this.title,
    required this.sourceDuration,
    String? id,
    this.path,
    this.libraryUrl,
    this.at = 0,
    this.start = 0,
    double? end,
    this.fileId,
  })  : id = id ?? studioId(),
        end = end ?? sourceDuration;

  final String id;
  String kind; // music | voice | extract | file
  String title;
  String? path, libraryUrl;
  double sourceDuration, at, start, end;
  double volume = 1, fadeIn = 0, fadeOut = 0;
  String? fileId;
  List<double> peaks = const [];

  double get length => math.max(.2, end - start);

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind,
        'title': title,
        'path': path,
        'libraryUrl': libraryUrl,
        'sourceDuration': sourceDuration,
        'at': at,
        'start': start,
        'end': end,
        'volume': volume,
        'fadeIn': fadeIn,
        'fadeOut': fadeOut,
        'fileId': fileId,
        'peaks': peaks,
      };

  static StudioAudio fromJson(Map j) => StudioAudio(
        kind: j['kind'] as String,
        title: j['title'] as String,
        sourceDuration: _d(j['sourceDuration'], 1),
        id: j['id'] as String,
        path: j['path'] as String?,
        libraryUrl: j['libraryUrl'] as String?,
        at: _d(j['at']),
        start: _d(j['start']),
        end: _d(j['end'], 1),
        fileId: j['fileId'] as String?,
      )
        ..volume = _d(j['volume'], 1)
        ..fadeIn = _d(j['fadeIn'])
        ..fadeOut = _d(j['fadeOut'])
        ..peaks = ((j['peaks'] as List?) ?? const []).map((e) => _d(e)).toList();

  StudioAudio duplicate() => fromJson({...toJson(), 'id': studioId()});

  Map<String, dynamic> plan() => {
        if (libraryUrl != null) 'library_url': libraryUrl else 'file_id': fileId,
        'at': double.parse(at.toStringAsFixed(3)),
        'start': double.parse(start.toStringAsFixed(3)),
        'end': double.parse(end.toStringAsFixed(3)),
        'volume': volume,
        'fade_in': fadeIn,
        'fade_out': fadeOut,
      };
}

// -- project -------------------------------------------------------------------------

class StudioProject {
  final clips = <StudioClip>[];
  final overlays = <StudioOverlay>[];
  final audios = <StudioAudio>[];
  String ratio = '9:16';
  int resolution = 1080, fps = 30;
  String background = 'blur'; // blur | #rrggbb
  double blur = .6;
  bool muteOriginal = false;

  double overlapAfter(int i) {
    if (i < 0 || i >= clips.length - 1) return 0;
    final a = clips[i], b = clips[i + 1];
    if (a.transition == 'none') return 0;
    return [a.transitionDuration, a.length / 3, b.length / 3].reduce(math.min);
  }

  /// Timeline start of every clip (transitions overlap neighbours).
  List<double> get starts {
    final out = <double>[];
    var t = 0.0;
    for (var i = 0; i < clips.length; i++) {
      out.add(t);
      t += clips[i].length - overlapAfter(i);
    }
    return out;
  }

  double get total {
    if (clips.isEmpty) return 0;
    final s = starts;
    return s.last + clips.last.length;
  }

  /// (clip index, local time) at timeline time [t].
  (int, double) clipAt(double t) {
    final s = starts;
    for (var i = clips.length - 1; i >= 0; i--) {
      if (t >= s[i] - 1e-6) {
        return (i, (t - s[i]).clamp(0.0, clips[i].length));
      }
    }
    return (0, 0);
  }

  double get aspect {
    const fixed = {
      '9:16': 9 / 16,
      '16:9': 16 / 9,
      '1:1': 1.0,
      '4:5': 4 / 5,
      '3:4': 3 / 4,
      '4:3': 4 / 3,
      '2:1': 2.0,
    };
    return fixed[ratio] ?? _originalAspect ?? 9 / 16;
  }

  double? _originalAspect;
  void setOriginalAspect(double? value) => _originalAspect = value;

  bool get isSinglePhoto =>
      clips.length == 1 &&
      clips.first.kind == 'image' &&
      audios.isEmpty &&
      clips.first.motion == 'none' &&
      clips.first.animIn == 'none' &&
      clips.first.animOut == 'none' &&
      !const {'shake', 'flash'}.contains(clips.first.effect);

  String snapshot() => jsonEncode({
        'clips': [for (final c in clips) c.toJson()],
        'overlays': [for (final o in overlays) o.toJson()],
        'audios': [for (final a in audios) a.toJson()],
        'ratio': ratio,
        'resolution': resolution,
        'fps': fps,
        'background': background,
        'blur': blur,
        'muteOriginal': muteOriginal,
      });

  void restore(String json) {
    final j = jsonDecode(json) as Map;
    clips
      ..clear()
      ..addAll([for (final c in j['clips'] as List) StudioClip.fromJson(c as Map)]);
    overlays
      ..clear()
      ..addAll([
        for (final o in j['overlays'] as List) StudioOverlay.fromJson(o as Map)
      ]);
    audios
      ..clear()
      ..addAll([for (final a in j['audios'] as List) StudioAudio.fromJson(a as Map)]);
    ratio = j['ratio'] as String;
    resolution = (j['resolution'] as num).toInt();
    fps = (j['fps'] as num).toInt();
    background = j['background'] as String;
    blur = _d(j['blur'], .6);
    muteOriginal = j['muteOriginal'] == true;
  }
}

// -- colour ----------------------------------------------------------------------------

const _identity = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0];

bool _isIdentity(List<double> m) {
  for (var i = 0; i < 12; i++) {
    if ((m[i] - _identity[i]).abs() > 1e-3) return false;
  }
  return true;
}

/// a ∘ b for 3x4 affine colour matrices (row-major, offset last, 0-1 units).
List<double> mulColor(List<double> a, List<double> b) {
  final out = List<double>.filled(12, 0);
  for (var r = 0; r < 3; r++) {
    for (var c = 0; c < 3; c++) {
      var v = 0.0;
      for (var k = 0; k < 3; k++) {
        v += a[r * 4 + k] * b[k * 4 + c];
      }
      out[r * 4 + c] = v;
    }
    var o = a[r * 4 + 3];
    for (var k = 0; k < 3; k++) {
      o += a[r * 4 + k] * b[k * 4 + 3];
    }
    out[r * 4 + 3] = o;
  }
  return out;
}

List<double> _saturation(double s) {
  final lr = .2126 * (1 - s), lg = .7152 * (1 - s), lb = .0722 * (1 - s);
  return [lr + s, lg, lb, 0, lr, lg + s, lb, 0, lr, lg, lb + s, 0];
}

List<double> _contrast(double k, [double lift = 0]) {
  final o = .5 * (1 - k) + lift;
  return [k, 0, 0, o, 0, k, 0, o, 0, 0, k, o];
}

List<double> _scale(double r, double g, double b, [double o = 0]) =>
    [r, 0, 0, o, 0, g, 0, o, 0, 0, b, o];

List<double> _offset(double r, double g, double b) =>
    [1, 0, 0, r, 0, 1, 0, g, 0, 0, 1, b];

List<double> _hue(double degrees) {
  final a = degrees * math.pi / 180;
  final c = math.cos(a), s = math.sin(a);
  const lr = .213, lg = .715, lb = .072;
  return [
    lr + c * (1 - lr) + s * -lr,
    lg + c * -lg + s * -lg,
    lb + c * -lb + s * (1 - lb),
    0,
    lr + c * -lr + s * .143,
    lg + c * (1 - lg) + s * .14,
    lb + c * -lb + s * -.283,
    0,
    lr + c * -lr + s * -(1 - lr),
    lg + c * -lg + s * lg,
    lb + c * (1 - lb) + s * lb,
    0,
  ];
}

List<double> _chain(List<List<double>> ms) =>
    ms.fold(List.of(_identity), (acc, m) => mulColor(m, acc));

/// Filter presets (CapCut-style names in Phlio's palette).
final Map<String, List<double>> studioFilters = {
  'none': List.of(_identity),
  'vivid': _chain([_saturation(1.35), _contrast(1.08)]),
  'warm': [1.1, 0, 0, .02, 0, 1.02, 0, .01, 0, 0, .86, -.02],
  'cool': [.9, 0, 0, -.01, 0, 1, 0, 0, 0, 0, 1.12, .03],
  'mono': _saturation(0),
  'noir': _chain([_saturation(0), _contrast(1.35)]),
  'fade': _chain([_saturation(.85), _contrast(.82, .08)]),
  'vintage': _chain([
    [.393, .769, .189, 0, .349, .686, .168, 0, .272, .534, .131, 0],
    _contrast(.9, .04),
  ]),
  'cinematic': _chain([
    [1.08, -.04, -.04, 0, -.02, 1, .02, 0, -.06, .04, 1.04, .03],
    _contrast(1.1),
  ]),
  'pastel': _chain([_saturation(.7), _contrast(.88, .06)]),
  'sunset': _chain([_scale(1.08, .97, 1.0), _offset(.03, -.01, .02), _contrast(1.04)]),
  'dream': _chain([_scale(.98, .94, 1.08), _offset(.03, 0, .05), _contrast(.92)]),
  'moody': _chain([_saturation(.8), _contrast(1.12), _offset(-.02, -.01, .02)]),
  'golden': _chain([_scale(1.12, 1.04, .82), _offset(.03, .02, -.02), _saturation(1.1)]),
  'teal': _chain([_scale(.9, 1.02, 1.08), _offset(-.02, .02, .03), _contrast(1.06)]),
};

const studioFilterNames = {
  'none': 'None',
  'vivid': 'Vivid',
  'warm': 'Warm',
  'cool': 'Cool',
  'mono': 'Mono',
  'noir': 'Noir',
  'fade': 'Fade',
  'vintage': 'Vintage',
  'cinematic': 'Cinematic',
  'pastel': 'Pastel',
  'sunset': 'Sunset',
  'dream': 'Dream',
  'moody': 'Moody',
  'golden': 'Golden',
  'teal': 'Teal',
};

/// Adjustment keys, all in -1..1 (vignette/sharpen/grain/fade in 0..1).
const studioAdjustments = [
  ('brightness', 'Brightness'),
  ('contrast', 'Contrast'),
  ('saturation', 'Saturation'),
  ('exposure', 'Exposure'),
  ('temperature', 'Temp'),
  ('tint', 'Tint'),
  ('hue', 'Hue'),
  ('fade', 'Fade'),
  ('vignette', 'Vignette'),
  ('sharpen', 'Sharpen'),
  ('grain', 'Grain'),
];

const studioUnipolar = {'fade', 'vignette', 'sharpen', 'grain'};

List<double> studioColorMatrix(
    String filter, double amount, Map<String, double> adjust) {
  final f = studioFilters[filter] ?? _identity;
  final blended = [
    for (var i = 0; i < 12; i++) _identity[i] + (f[i] - _identity[i]) * amount
  ];
  double a(String k) => adjust[k] ?? 0;
  final steps = <List<double>>[blended];
  if (a('exposure') != 0) {
    final e = math.pow(2, a('exposure')).toDouble();
    steps.add(_scale(e, e, e));
  }
  if (a('temperature') != 0) {
    final t = a('temperature');
    steps.add(_scale(1 + .12 * t, 1 + .02 * t, 1 - .12 * t));
  }
  if (a('tint') != 0) {
    final t = a('tint');
    steps.add(_scale(1 + .05 * t, 1 - .1 * t, 1 + .05 * t));
  }
  if (a('hue') != 0) steps.add(_hue(a('hue') * 60));
  if (a('saturation') != 0) steps.add(_saturation(1 + a('saturation')));
  if (a('contrast') != 0) steps.add(_contrast(1 + .5 * a('contrast')));
  if (a('fade') != 0) steps.add(_contrast(1 - .3 * a('fade'), .15 * a('fade')));
  if (a('brightness') != 0) {
    final b = .22 * a('brightness');
    steps.add(_offset(b, b, b));
  }
  final m = _chain(steps);
  return [for (final v in m) v.clamp(-2.0, 2.0)];
}

/// 4x5 matrix for [ColorFilter.matrix] (offsets in 0-255).
List<double> flutterColorMatrix(List<double> m) => [
      m[0], m[1], m[2], 0, m[3] * 255, //
      m[4], m[5], m[6], 0, m[7] * 255,
      m[8], m[9], m[10], 0, m[11] * 255,
      0, 0, 0, 1, 0,
    ];

bool isIdentityColor(List<double> m) => _isIdentity(m);

// -- catalogues --------------------------------------------------------------------------

const studioEffects = [
  ('none', 'None'),
  ('vignette', 'Vignette'),
  ('grain', 'Film grain'),
  ('blur', 'Blur'),
  ('soft', 'Soft glow'),
  ('glitch', 'Glitch'),
  ('rgb_split', 'RGB split'),
  ('vhs', 'VHS'),
  ('film', 'Old film'),
  ('mirror', 'Mirror'),
  ('shake', 'Shake'),
  ('flash', 'Flash'),
  ('pixelate', 'Pixelate'),
];

const studioTransitions = [
  ('none', 'None'),
  ('fade', 'Mix'),
  ('fadeblack', 'Black fade'),
  ('fadewhite', 'Flash white'),
  ('dissolve', 'Dissolve'),
  ('slideleft', 'Slide left'),
  ('slideright', 'Slide right'),
  ('slideup', 'Slide up'),
  ('slidedown', 'Slide down'),
  ('wipeleft', 'Wipe'),
  ('circleopen', 'Circle open'),
  ('circleclose', 'Circle close'),
  ('radial', 'Radial'),
  ('zoomin', 'Zoom in'),
  ('pixelize', 'Pixelize'),
  ('hblur', 'Blur'),
  ('smoothleft', 'Smooth'),
  ('squeezeh', 'Squeeze'),
  ('distance', 'Distance'),
];

const studioRatios = [
  ('original', 'Original'),
  ('9:16', '9:16'),
  ('1:1', '1:1'),
  ('4:5', '4:5'),
  ('16:9', '16:9'),
  ('3:4', '3:4'),
  ('4:3', '4:3'),
  ('2:1', '2:1'),
];

const studioTextFonts = [
  ('Manrope', 'Classic'),
  ('Quicksand', 'Round'),
  ('serif', 'Serif'),
  ('monospace', 'Mono'),
];

const studioTextStyles = [
  ('plain', 'Plain'),
  ('shadow', 'Shadow'),
  ('box', 'Label'),
  ('outline', 'Outline'),
  ('neon', 'Neon'),
  ('gradient', 'Phlio'),
];

const studioSwatches = [
  0xFFFFFFFF, 0xFF0B0F17, 0xFF8D78FF, 0xFFFFB58F, 0xFFE795D7, 0xFF68D7CD,
  0xFF72A7FF, 0xFFF5636B, 0xFFF6B93B, 0xFF4CD964, 0xFFFF9500, 0xFF5856D6,
];
