// CapCut-style timeline: fixed centre playhead, scrolling ruler, main clip
// track with film strips + transition buttons, an audio lane and text /
// sticker lanes. Pinch with two fingers to zoom.

import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../../../design_system/colors.dart';
import 'studio_model.dart';

enum StudioSelectKind { none, clip, audio, overlay }

class StudioSelection {
  const StudioSelection(this.kind, [this.id]);
  const StudioSelection.none() : this(StudioSelectKind.none);
  final StudioSelectKind kind;
  final String? id;
  bool get isNone => kind == StudioSelectKind.none;
  bool matches(StudioSelectKind k, String i) => kind == k && id == i;
}

class StudioTimeline extends StatefulWidget {
  const StudioTimeline({
    required this.project,
    required this.t,
    required this.pps,
    required this.selection,
    required this.strips,
    required this.onScrubStart,
    required this.onScrub,
    required this.onZoom,
    required this.onSelect,
    required this.onTrimClip,
    required this.onTrimItem,
    required this.onMoveItem,
    required this.onEditEnd,
    required this.onTransition,
    required this.onAddClip,
    required this.onAddAudio,
    required this.onAddText,
    required this.onToggleMute,
    super.key,
  });

  final StudioProject project;
  final double t, pps;
  final StudioSelection selection;
  final Map<String, ui.Image> strips; // clip fileId -> film strip
  final VoidCallback onScrubStart, onAddClip, onAddAudio, onAddText, onToggleMute, onEditEnd;
  final ValueChanged<double> onScrub, onZoom;
  final ValueChanged<StudioSelection> onSelect;
  final void Function(int index, bool head, double seconds) onTrimClip;
  final void Function(StudioSelection item, bool head, double seconds) onTrimItem;
  final void Function(StudioSelection item, double seconds) onMoveItem;
  final ValueChanged<int> onTransition;

  @override
  State<StudioTimeline> createState() => _StudioTimelineState();
}

const _ruler = 24.0, _main = 58.0, _lane = 34.0, _gap = 8.0;
const _violet = PhlioColors.brandViolet;
const _peach = PhlioColors.brandPeach;
const _pink = PhlioColors.brandPink;
const _teal = Color(0xFF68D7CD);

class _StudioTimelineState extends State<StudioTimeline> {
  final _scroll = ScrollController();
  bool _user = false;
  final Map<int, Offset> _pointers = {};
  double? _pinchStart, _ppsStart;

  @override
  void didUpdateWidget(StudioTimeline old) {
    super.didUpdateWidget(old);
    WidgetsBinding.instance.addPostFrameCallback((_) => _sync());
  }

  void _sync() {
    if (!mounted || _user || !_scroll.hasClients) return;
    final target = widget.t * widget.pps;
    if ((_scroll.offset - target).abs() > .5) {
      _scroll.jumpTo(target.clamp(0.0, _scroll.position.maxScrollExtent));
    }
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  List<List<StudioOverlay>> _lanes() {
    final lanes = <List<StudioOverlay>>[];
    final sorted = [...widget.project.overlays]..sort((a, b) => a.start.compareTo(b.start));
    for (final o in sorted) {
      final lane = lanes.where((l) => l.last.end <= o.start + 1e-3).firstOrNull;
      if (lane != null) {
        lane.add(o);
      } else {
        lanes.add([o]);
      }
    }
    return lanes;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final half = box.maxWidth / 2;
      final p = widget.project;
      final pps = widget.pps;
      final total = p.total;
      final lanes = _lanes();
      final textLanes = math.max(1, lanes.length);
      final height = _ruler + _main + _gap + _lane + _gap + textLanes * (_lane + 4) + 16;
      final width = total * pps + box.maxWidth;
      return Listener(
        onPointerDown: (e) {
          _pointers[e.pointer] = e.position;
          if (_pointers.length == 2) {
            final v = _pointers.values.toList();
            _pinchStart = (v[0] - v[1]).distance;
            _ppsStart = widget.pps;
          }
        },
        onPointerMove: (e) {
          if (!_pointers.containsKey(e.pointer)) return;
          _pointers[e.pointer] = e.position;
          if (_pointers.length == 2 && _pinchStart != null && _pinchStart! > 10) {
            final v = _pointers.values.toList();
            final next = (_ppsStart! * (v[0] - v[1]).distance / _pinchStart!).clamp(16.0, 260.0);
            widget.onZoom(next);
          }
        },
        onPointerUp: (e) {
          _pointers.remove(e.pointer);
          if (_pointers.length < 2) _pinchStart = null;
        },
        onPointerCancel: (e) => _pointers.remove(e.pointer),
        child: Stack(children: [
          NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n is ScrollStartNotification && n.dragDetails != null) {
                _user = true;
                widget.onScrubStart();
              } else if (n is ScrollUpdateNotification && _user) {
                widget.onScrub((n.metrics.pixels / pps).clamp(0.0, total));
              } else if (n is ScrollEndNotification) {
                _user = false;
              }
              return false;
            },
            child: SingleChildScrollView(
              controller: _scroll,
              scrollDirection: Axis.horizontal,
              physics: const ClampingScrollPhysics(),
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: () => widget.onSelect(const StudioSelection.none()),
                child: SizedBox(
                  width: width,
                  height: height,
                  child: Stack(clipBehavior: Clip.none, children: [
                    Positioned(
                      left: half,
                      top: 0,
                      width: total * pps,
                      height: _ruler,
                      child: CustomPaint(painter: _RulerPainter(pps, total)),
                    ),
                    // Leading controls, CapCut-style.
                    Positioned(
                      left: half - 74,
                      top: _ruler,
                      width: 66,
                      height: _main,
                      child: _MuteToggle(muted: p.muteOriginal, onTap: widget.onToggleMute),
                    ),
                    ..._clips(half),
                    Positioned(
                      left: half + total * pps + 10,
                      top: _ruler + (_main - 40) / 2,
                      child: _AddButton(onTap: widget.onAddClip),
                    ),
                    ..._audios(half, _ruler + _main + _gap),
                    ..._overlayLanes(half, _ruler + _main + _gap + _lane + _gap, lanes),
                  ]),
                ),
              ),
            ),
          ),
          // Centre playhead.
          Positioned(
            left: half - 1,
            top: 0,
            bottom: 0,
            child: IgnorePointer(
              child: Container(
                width: 2,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(1),
                  boxShadow: [
                    BoxShadow(color: Colors.black.withValues(alpha: .4), blurRadius: 4)
                  ],
                ),
              ),
            ),
          ),
        ]),
      );
    });
  }

  List<Widget> _clips(double half) {
    final p = widget.project;
    final pps = widget.pps;
    final starts = p.starts;
    final out = <Widget>[];
    for (var i = 0; i < p.clips.length; i++) {
      final c = p.clips[i];
      final selected = widget.selection.matches(StudioSelectKind.clip, c.id);
      final visible = (c.length - p.overlapAfter(i)) * pps;
      final left = half + starts[i] * pps;
      out.add(Positioned(
        left: left,
        top: _ruler,
        width: math.max(6, visible - 2),
        height: _main,
        child: GestureDetector(
          onTap: () => widget.onSelect(StudioSelection(StudioSelectKind.clip, c.id)),
          child: _ClipBox(
            clip: c,
            strip: c.fileId == null ? null : widget.strips[c.fileId],
            selected: selected,
            pps: pps,
          ),
        ),
      ));
      if (selected) {
        out.add(_handle(left - 14, _ruler, _main, (dx) => widget.onTrimClip(i, true, dx / pps)));
        out.add(_handle(left + visible - 2, _ruler, _main, (dx) => widget.onTrimClip(i, false, dx / pps)));
      }
      if (i < p.clips.length - 1) {
        final x = half + starts[i + 1] * pps;
        out.add(Positioned(
          left: x - 13,
          top: _ruler + _main / 2 - 13,
          child: GestureDetector(
            onTap: () => widget.onTransition(i),
            child: Container(
              width: 26,
              height: 26,
              decoration: BoxDecoration(
                color: c.transition == 'none' ? Colors.white : _violet,
                borderRadius: BorderRadius.circular(6),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .4), blurRadius: 6)],
              ),
              child: Icon(
                c.transition == 'none' ? Icons.horizontal_rule_rounded : Icons.auto_awesome_motion_rounded,
                size: 15,
                color: c.transition == 'none' ? const Color(0xFF0B0F17) : Colors.white,
              ),
            ),
          ),
        ));
      }
    }
    return out;
  }

  Widget _handle(double left, double top, double height, ValueChanged<double> onDrag) => Positioned(
        left: left,
        top: top,
        width: 16,
        height: height,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onHorizontalDragUpdate: (d) => onDrag(d.delta.dx),
          onHorizontalDragEnd: (_) => widget.onEditEnd(),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(
              child: Container(
                width: 2.5,
                height: height * .36,
                decoration: BoxDecoration(
                    color: const Color(0xFF0B0F17), borderRadius: BorderRadius.circular(2)),
              ),
            ),
          ),
        ),
      );

  List<Widget> _audios(double half, double top) {
    final p = widget.project;
    final pps = widget.pps;
    if (p.audios.isEmpty) {
      return [
        Positioned(
          left: half,
          top: top,
          height: _lane,
          child: _AddLane(icon: Icons.music_note_rounded, label: 'Add audio', onTap: widget.onAddAudio),
        ),
      ];
    }
    final out = <Widget>[];
    for (final a in p.audios) {
      final sel = StudioSelection(StudioSelectKind.audio, a.id);
      final selected = widget.selection.matches(StudioSelectKind.audio, a.id);
      final left = half + a.at * pps;
      final w = math.max(8.0, a.length * pps);
      final color = a.kind == 'voice' ? _peach : a.kind == 'extract' ? _teal : _violet;
      out.add(Positioned(
        left: left,
        top: top,
        width: w,
        height: _lane,
        child: GestureDetector(
          onTap: () => widget.onSelect(sel),
          onHorizontalDragUpdate: selected ? (d) => widget.onMoveItem(sel, d.delta.dx / pps) : null,
          onHorizontalDragEnd: selected ? (_) => widget.onEditEnd() : null,
          child: _Pill(
            color: color,
            selected: selected,
            icon: a.kind == 'voice' ? Icons.mic_rounded : Icons.music_note_rounded,
            label: a.title,
            peaks: a.peaks,
            peakOffset: a.sourceDuration > 0 ? a.start / a.sourceDuration : 0,
            peakSpan: a.sourceDuration > 0 ? a.length / a.sourceDuration : 1,
          ),
        ),
      ));
      if (selected) {
        out.add(_handle(left - 14, top, _lane, (dx) => widget.onTrimItem(sel, true, dx / pps)));
        out.add(_handle(left + w - 2, top, _lane, (dx) => widget.onTrimItem(sel, false, dx / pps)));
      }
    }
    return out;
  }

  List<Widget> _overlayLanes(double half, double top, List<List<StudioOverlay>> lanes) {
    final pps = widget.pps;
    if (lanes.isEmpty) {
      return [
        Positioned(
          left: half,
          top: top,
          height: _lane,
          child: _AddLane(icon: Icons.text_fields_rounded, label: 'Add text', onTap: widget.onAddText),
        ),
      ];
    }
    final out = <Widget>[];
    for (var l = 0; l < lanes.length; l++) {
      final y = top + l * (_lane + 4);
      for (final o in lanes[l]) {
        final sel = StudioSelection(StudioSelectKind.overlay, o.id);
        final selected = widget.selection.matches(StudioSelectKind.overlay, o.id);
        final left = half + o.start * pps;
        final w = math.max(8.0, (o.end - o.start) * pps);
        out.add(Positioned(
          left: left,
          top: y,
          width: w,
          height: _lane,
          child: GestureDetector(
            onTap: () => widget.onSelect(sel),
            onHorizontalDragUpdate: selected ? (d) => widget.onMoveItem(sel, d.delta.dx / pps) : null,
            onHorizontalDragEnd: selected ? (_) => widget.onEditEnd() : null,
            child: _Pill(
              color: o.kind == 'text' ? _peach : _pink,
              selected: selected,
              icon: o.kind == 'text' ? Icons.text_fields_rounded : Icons.emoji_emotions_outlined,
              label: o.label,
            ),
          ),
        ));
        if (selected) {
          out.add(_handle(left - 14, y, _lane, (dx) => widget.onTrimItem(sel, true, dx / pps)));
          out.add(_handle(left + w - 2, y, _lane, (dx) => widget.onTrimItem(sel, false, dx / pps)));
        }
      }
    }
    return out;
  }
}

class _ClipBox extends StatelessWidget {
  const _ClipBox({required this.clip, required this.strip, required this.selected, required this.pps});
  final StudioClip clip;
  final ui.Image? strip;
  final bool selected;
  final double pps;

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (clip.kind == 'image') {
      body = DecoratedBox(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: ResizeImage(FileImage(File(clip.path)), height: 140),
            fit: BoxFit.fitHeight,
            repeat: ImageRepeat.repeatX,
            alignment: Alignment.centerLeft,
          ),
        ),
      );
    } else if (strip != null) {
      body = CustomPaint(painter: _StripPainter(strip!, clip));
    } else {
      body = DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF2A2350), Color(0xFF3B3470)]),
        ),
        child: const Center(
          child: SizedBox(
              width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 1.6)),
        ),
      );
    }
    final badges = <Widget>[
      if (clip.speed != 1) _Badge('${_fmt(clip.speed)}x'),
      if (clip.reverse) const _Badge('↺'),
      if (clip.hold != null) const _Badge('❄'),
      if (clip.volume == 0) const _Badge('🔇'),
      if (clip.filter != 'none') const _Badge('◐'),
      if (clip.effect != 'none') const _Badge('✦'),
    ];
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: Stack(fit: StackFit.expand, children: [
        ColorFiltered(
          colorFilter: ColorFilter.matrix(flutterColorMatrix(clip.colorMatrix)),
          child: body,
        ),
        Positioned(
          left: 4,
          top: 4,
          child: Row(mainAxisSize: MainAxisSize.min, children: badges),
        ),
        Positioned(
          right: 4,
          bottom: 3,
          child: Text(_fmt(clip.length) + 's',
              style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  shadows: [Shadow(blurRadius: 3)])),
        ),
        if (selected)
          DecoratedBox(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white, width: 2.2),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
      ]),
    );
  }
}

String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(1);

class _Badge extends StatelessWidget {
  const _Badge(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(right: 3),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
        decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: .55), borderRadius: BorderRadius.circular(4)),
        child: Text(text,
            style: const TextStyle(fontSize: 9.5, color: Colors.white, fontWeight: FontWeight.w800)),
      );
}

class _StripPainter extends CustomPainter {
  _StripPainter(this.strip, this.clip);
  final ui.Image strip;
  final StudioClip clip;
  @override
  void paint(Canvas canvas, Size size) {
    const frames = 12;
    final tileW = strip.width / frames, tileH = strip.height.toDouble();
    final dstW = size.height * tileW / tileH;
    final paint = Paint()..filterQuality = FilterQuality.medium;
    final dur = math.max(.1, clip.sourceDuration);
    for (var x = 0.0; x < size.width; x += dstW) {
      final local = (x + dstW / 2) / size.width * clip.length;
      final src = clip.sourceAt(local);
      final i = (src / dur * frames).floor().clamp(0, frames - 1);
      canvas.drawImageRect(strip, Rect.fromLTWH(i * tileW, 0, tileW, tileH),
          Rect.fromLTWH(x, 0, dstW, size.height), paint);
    }
  }

  @override
  bool shouldRepaint(_StripPainter old) => true;
}

class _Pill extends StatelessWidget {
  const _Pill({
    required this.color,
    required this.selected,
    required this.icon,
    required this.label,
    this.peaks = const [],
    this.peakOffset = 0,
    this.peakSpan = 1,
  });
  final Color color;
  final bool selected;
  final IconData icon;
  final String label;
  final List<double> peaks;
  final double peakOffset, peakSpan;
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: Color.alphaBlend(color.withValues(alpha: .28), const Color(0xFF151C29)),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: selected ? Colors.white : color.withValues(alpha: .7), width: selected ? 2 : 1),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (peaks.isNotEmpty)
            CustomPaint(painter: _PeaksPainter(peaks, color, peakOffset, peakSpan)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Row(children: [
              Icon(icon, size: 13, color: Colors.white),
              const SizedBox(width: 4),
              Expanded(
                child: Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
              ),
            ]),
          ),
        ]),
      );
}

class _PeaksPainter extends CustomPainter {
  _PeaksPainter(this.peaks, this.color, this.offset, this.span);
  final List<double> peaks;
  final Color color;
  final double offset, span;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color.withValues(alpha: .7);
    const bar = 3.0;
    for (var x = 0.0; x < size.width; x += bar + 1) {
      final f = offset + (x / size.width) * span;
      final i = (f * peaks.length).floor().clamp(0, peaks.length - 1);
      final h = math.max(2.0, peaks[i] * size.height * .8);
      canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(x, size.height - h - 2, bar, h), const Radius.circular(1)),
          paint);
    }
  }

  @override
  bool shouldRepaint(_PeaksPainter old) => true;
}

class _RulerPainter extends CustomPainter {
  _RulerPainter(this.pps, this.total);
  final double pps, total;
  @override
  void paint(Canvas canvas, Size size) {
    final step = pps >= 90 ? .5 : pps >= 40 ? 1.0 : pps >= 20 ? 2.0 : 5.0;
    final label = step <= 1 ? 2.0 : step * 2;
    final dot = Paint()..color = Colors.white.withValues(alpha: .35);
    for (var s = 0.0; s <= total + 1e-6; s += step) {
      final x = s * pps;
      if ((s / label - (s / label).round()).abs() < 1e-6) {
        final tp = TextPainter(
          text: TextSpan(
              text: _clock(s),
              style: TextStyle(fontSize: 10, color: Colors.white.withValues(alpha: .55))),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, Offset(x - tp.width / 2, 4));
      } else {
        canvas.drawCircle(Offset(x, 10), 1.4, dot);
      }
    }
  }

  @override
  bool shouldRepaint(_RulerPainter old) => old.pps != pps || old.total != total;
}

String _clock(double s) {
  final m = s ~/ 60, r = (s % 60).floor();
  return '${m.toString().padLeft(2, '0')}:${r.toString().padLeft(2, '0')}';
}

class _MuteToggle extends StatelessWidget {
  const _MuteToggle({required this.muted, required this.onTap});
  final bool muted;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
              size: 20, color: muted ? PhlioColors.danger : Colors.white),
          const SizedBox(height: 3),
          Text(muted ? 'Unmute\nclip audio' : 'Mute clip\naudio',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 9.5, height: 1.15, color: Colors.white70)),
        ]),
      );
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onTap});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(Icons.add_rounded, color: Color(0xFF0B0F17), size: 26),
        ),
      );
}

class _AddLane extends StatelessWidget {
  const _AddLane({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 170,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .06),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(children: [
            const Icon(Icons.add_rounded, size: 16, color: Colors.white70),
            const SizedBox(width: 4),
            Icon(icon, size: 14, color: Colors.white54),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ]),
        ),
      );
}
