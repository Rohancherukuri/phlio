"""Bounded, local FFmpeg composition for the DM editor (Phlio Studio).

The Flutter editor (CapCut-style) sends a plan:

  clips     main track, in order. Each clip: source file (photo or video),
            trim, speed, volume, rotate/flip, crop, reverse, freeze (hold a
            frame), a 3x4 colour matrix (filters + adjustments, computed on the
            device so preview and export match), vignette/sharpen/grain, one
            effect, fill/fit framing with zoom + pan, Ken Burns motion,
            fade in/out and the transition into the next clip.
  overlays  text / stickers / drawings rendered by the app as PNGs; placed by
            normalised position + width, shown between two times, with an
            in/out animation.
  audios    music (DM file or a Phlio Stream track), extracted audio and
            voiceovers, each placed on the timeline with trim, volume, fades.

Rendering: one encode per clip (normalised to the canvas), a chain that joins
them with cuts or xfade transitions, and a final pass that composites the
overlays and mixes the audio. Progress is reported per stage so the app can
show a real percentage.

Older clients (single global filter/text/music fields) still render.
"""
import json
import math
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Literal

from fastapi import HTTPException
from pydantic import BaseModel, Field, model_validator

TRANSITIONS = ('none', 'fade', 'fadeblack', 'fadewhite', 'dissolve', 'slideleft', 'slideright',
               'slideup', 'slidedown', 'wipeleft', 'wiperight', 'circleopen', 'circleclose', 'radial',
               'pixelize', 'hblur', 'zoomin', 'smoothleft', 'squeezeh', 'distance')
EFFECTS = ('none', 'vignette', 'grain', 'blur', 'glitch', 'vhs', 'film', 'mirror', 'shake', 'flash',
           'pixelate', 'soft', 'rgb_split')
Transition = Literal[TRANSITIONS]  # type: ignore[valid-type]
Effect = Literal[EFFECTS]  # type: ignore[valid-type]
FileId = Field(pattern=r'^[a-f0-9]{32}$')
LEGACY_FILTERS = {
    'mono': [.299, .587, .114, 0, .299, .587, .114, 0, .299, .587, .114, 0],
    'warm': [1.08, 0, 0, 0, 0, 1, 0, 0, 0, 0, .94, 0],
    'cool': [.94, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1.08, 0],
}


class StudioClip(BaseModel):
    file_id: str = FileId
    start: float = Field(default=0, ge=0, le=3600, allow_inf_nan=False)
    end: float = Field(default=3, gt=0, le=3600, allow_inf_nan=False)
    speed: float = Field(default=1, ge=0.25, le=4, allow_inf_nan=False)
    volume: float = Field(default=1, ge=0, le=2, allow_inf_nan=False)
    turns: int = Field(default=0, ge=0, le=3)
    flip: bool = False
    flip_v: bool = False
    reverse: bool = False
    hold: float | None = Field(default=None, ge=.3, le=30, allow_inf_nan=False)  # freeze frame
    crop: list[float] | None = Field(default=None, min_length=4, max_length=4)  # x, y, w, h (0-1)
    color: list[float] | None = Field(default=None, min_length=12, max_length=12)
    vignette: float = Field(default=0, ge=0, le=1, allow_inf_nan=False)
    sharpen: float = Field(default=0, ge=0, le=1, allow_inf_nan=False)
    grain: float = Field(default=0, ge=0, le=1, allow_inf_nan=False)
    effect: Effect = 'none'
    fit: Literal['fill', 'fit'] = 'fill'
    zoom: float = Field(default=1, ge=.5, le=4, allow_inf_nan=False)
    pan_x: float = Field(default=0, ge=-1, le=1, allow_inf_nan=False)
    pan_y: float = Field(default=0, ge=-1, le=1, allow_inf_nan=False)
    motion: Literal['none', 'zoom_in', 'zoom_out', 'pan_left', 'pan_right'] = 'none'
    anim_in: Literal['none', 'fade', 'fade_white'] = 'none'
    anim_out: Literal['none', 'fade', 'fade_white'] = 'none'
    fade_audio_in: float = Field(default=0, ge=0, le=10, allow_inf_nan=False)
    fade_audio_out: float = Field(default=0, ge=0, le=10, allow_inf_nan=False)
    transition: Transition = 'none'  # into the next clip
    transition_duration: float = Field(default=.5, ge=.1, le=2, allow_inf_nan=False)

    @model_validator(mode='after')
    def valid(self):
        if self.hold is None and self.end - self.start < .3:
            raise ValueError('Each clip must be at least 0.3 seconds.')
        if self.crop:
            x, y, w, h = self.crop
            if not (0 <= x < 1 and 0 <= y < 1 and .05 <= w <= 1 and .05 <= h <= 1 and x + w <= 1.001 and y + h <= 1.001):
                raise ValueError('Invalid crop.')
        if self.color and any(not math.isfinite(v) or abs(v) > 2 for v in self.color):
            raise ValueError('Invalid colour adjustment.')
        if self.reverse and self.end - self.start > 30:
            raise ValueError('Reverse works on clips up to 30 seconds.')
        return self

    @property
    def length(self) -> float:
        if self.hold is not None:
            return self.hold
        return max(.3, (self.end - self.start) / self.speed)


class StudioOverlay(BaseModel):
    file_id: str = FileId  # PNG rendered by the app
    x: float = Field(ge=-1, le=2, allow_inf_nan=False)  # top-left, fraction of canvas
    y: float = Field(ge=-1, le=2, allow_inf_nan=False)
    w: float = Field(gt=0, le=3, allow_inf_nan=False)  # width, fraction of canvas width
    start: float = Field(default=0, ge=0, le=3600, allow_inf_nan=False)
    end: float = Field(default=3600, gt=0, le=3600, allow_inf_nan=False)
    anim_in: Literal['none', 'fade', 'slide_up', 'slide_left'] = 'fade'
    anim_out: Literal['none', 'fade'] = 'fade'


class StudioAudio(BaseModel):
    file_id: str | None = Field(default=None, pattern=r'^[a-f0-9]{32}$')
    library_url: str | None = Field(default=None, max_length=300)  # /media/stream_music/...
    at: float = Field(default=0, ge=0, le=3600, allow_inf_nan=False)  # timeline position
    start: float = Field(default=0, ge=0, le=7200, allow_inf_nan=False)  # in-point in the source
    end: float | None = Field(default=None, gt=0, le=7200, allow_inf_nan=False)
    volume: float = Field(default=1, ge=0, le=2, allow_inf_nan=False)
    fade_in: float = Field(default=0, ge=0, le=10, allow_inf_nan=False)
    fade_out: float = Field(default=0, ge=0, le=10, allow_inf_nan=False)
    loop: bool = False

    @model_validator(mode='after')
    def one_source(self):
        if bool(self.file_id) == bool(self.library_url):
            raise ValueError('Each audio item needs exactly one source.')
        if self.library_url and (not self.library_url.startswith('/media/stream_music/')
                                 or '..' in self.library_url):
            raise ValueError('Only Phlio Stream tracks can be used.')
        return self


class StudioPlan(BaseModel):
    clips: list[StudioClip] = Field(min_length=1, max_length=20)
    overlays: list[StudioOverlay] = Field(default_factory=list, max_length=30)
    audios: list[StudioAudio] = Field(default_factory=list, max_length=8)
    mute_original: bool = False
    ratio: Literal['original', '9:16', '16:9', '1:1', '4:5', '3:4', '4:3', '2:1'] = '9:16'
    resolution: Literal[480, 720, 1080] = 720
    fps: Literal[24, 30, 60] = 30
    background: str = Field(default='blur', pattern=r'^(blur|#[0-9a-fA-F]{6})$')
    blur: float = Field(default=.6, ge=0, le=1, allow_inf_nan=False)
    image_format: Literal['jpg', 'png'] = 'jpg'
    # Legacy (v1 editor) fields.
    music_id: str | None = Field(default=None, pattern=r'^[a-f0-9]{32}$')
    music_volume: float = Field(default=.3, ge=0, le=1, allow_inf_nan=False)
    transition: Literal['none', 'fade', 'dissolve', 'slideleft'] = 'none'
    filter: Literal['normal', 'mono', 'warm', 'cool'] = 'normal'
    brightness: float = Field(default=0, ge=-.3, le=.3, allow_inf_nan=False)
    contrast: float = Field(default=1, ge=.5, le=1.5, allow_inf_nan=False)
    saturation: float = Field(default=1, ge=0, le=2, allow_inf_nan=False)
    text: str = Field(default='', max_length=180)

    @model_validator(mode='after')
    def bounded(self):
        if sum(c.length for c in self.clips) > 300:
            raise ValueError('Keep projects within five minutes.')
        return self

    @property
    def total(self) -> float:
        total = 0.0
        for i, clip in enumerate(self.clips):
            total += clip.length
            if i and self.clips[i - 1].transition != 'none':
                total -= overlap(self.clips[i - 1], clip)
        return total

    @property
    def image_only(self) -> bool:
        c = self.clips[0]
        return (len(self.clips) == 1 and c.motion == 'none' and not self.audios and not self.music_id
                and c.anim_in == 'none' and c.anim_out == 'none' and c.effect not in ('shake', 'flash'))


def overlap(a: StudioClip, b: StudioClip) -> float:
    return min(a.transition_duration, a.length / 3, b.length / 3)


def legacy_matrix(plan: StudioPlan) -> list[float] | None:
    """v1 editor: one filter + eq sliders for the whole project."""
    if plan.filter == 'normal' and plan.brightness == 0 and plan.contrast == 1 and plan.saturation == 1:
        return None
    m = LEGACY_FILTERS.get(plan.filter, [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0])
    s = plan.saturation
    lr, lg, lb = .2126 * (1 - s), .7152 * (1 - s), .0722 * (1 - s)
    sat = [lr + s, lg, lb, 0, lr, lg + s, lb, 0, lr, lg, lb + s, 0]
    k = plan.contrast
    con = [k, 0, 0, .5 * (1 - k) + plan.brightness, 0, k, 0, .5 * (1 - k) + plan.brightness,
           0, 0, k, .5 * (1 - k) + plan.brightness]
    return mul(con, mul(sat, m))


def mul(a, b):
    """3x4 affine colour matrices: a ∘ b."""
    out = []
    for r in range(3):
        row = a[r * 4:r * 4 + 4]
        for col in range(3):
            out.append(sum(row[k] * b[k * 4 + col] for k in range(3)))
        out.append(sum(row[k] * b[k * 4 + 3] for k in range(3)) + row[3])
    return out


def atempo(speed: float) -> str:
    parts = []
    while speed > 2:
        parts.append('atempo=2')
        speed /= 2
    while speed < .5:
        parts.append('atempo=0.5')
        speed /= .5
    parts.append(f'atempo={speed:.5f}')
    return ','.join(parts)


def canvas(plan: StudioPlan, first: dict) -> tuple[int, int]:
    ratios = {'9:16': 9 / 16, '16:9': 16 / 9, '1:1': 1, '4:5': 4 / 5, '3:4': 3 / 4, '4:3': 4 / 3, '2:1': 2}
    clip = plan.clips[0]
    w, h = first['width'], first['height']
    if clip.turns % 2:
        w, h = h, w
    if clip.crop:
        w, h = w * clip.crop[2], h * clip.crop[3]
    ratio = ratios.get(plan.ratio, w / h)
    short = plan.resolution
    width = short if ratio <= 1 else short * ratio
    height = short / ratio if ratio <= 1 else short
    scale = min(1, 1920 / max(width, height))
    return int(width * scale) // 4 * 4, int(height * scale) // 4 * 4


def color_filters(clip: StudioClip, legacy: list[float] | None) -> list[str]:
    m = clip.color or legacy
    out = []
    if m and m != [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0]:
        out.append('colorchannelmixer=' + ':'.join(
            f'{n}={v:.4f}' for n, v in zip(
                ['rr', 'rg', 'rb', 'gr', 'gg', 'gb', 'br', 'bg', 'bb'],
                [m[0], m[1], m[2], m[4], m[5], m[6], m[8], m[9], m[10]])))
        offsets = [m[3], m[7], m[11]]
        if any(abs(o) > .002 for o in offsets):
            out.append("lutrgb=" + ':'.join(
                f"{c}='clip(val+{round(o * 255)},0,255)'" for c, o in zip('rgb', offsets)))
    if clip.sharpen > 0:
        out.append(f'unsharp=5:5:{clip.sharpen * 1.6:.2f}')
    if clip.grain > 0:
        out.append(f'noise=alls={round(clip.grain * 28)}:allf=t+u')
    if clip.vignette > 0:
        out.append(f'vignette=angle={0.25 + clip.vignette * 0.55:.3f}')
    return out


def effect_graph(effect: str, src: str, dst: str, W: int, H: int) -> str:
    simple = {
        'none': 'null',
        'vignette': 'vignette=angle=PI/4',
        'grain': 'noise=alls=16:allf=t+u',
        'blur': 'gblur=sigma=8',
        'glitch': 'rgbashift=rh=-10:bh=10,noise=alls=10:allf=t',
        'vhs': "curves=preset=vintage,rgbashift=rh=4:bh=-4,noise=alls=12:allf=t,eq=saturation=1.25",
        'film': 'hue=s=0,eq=contrast=1.15,noise=alls=18:allf=t+u,vignette=angle=PI/4',
        'shake': (f"crop=w=iw*0.9:h=ih*0.9:x=(iw-ow)/2+sin(t*37)*iw*0.025:y=(ih-oh)/2+cos(t*29)*ih*0.025,"
                  f"scale={W}:{H}"),
        'flash': "eq=brightness='0.3*pow(max(0,sin(t*5)),8)':eval=frame",
        'pixelate': f'scale={max(8, W // 18)}:{max(8, H // 18)},scale={W}:{H}:flags=neighbor',
        'rgb_split': 'rgbashift=rh=-7:bv=7',
    }
    if effect in simple:
        return f'[{src}]{simple[effect]}[{dst}]'
    if effect == 'mirror':
        return (f'[{src}]crop=iw/2:ih:0:0,split[{dst}l][{dst}r];[{dst}r]hflip[{dst}f];'
                f'[{dst}l][{dst}f]hstack,scale={W}:{H}[{dst}]')
    if effect == 'soft':
        return (f'[{src}]split[{dst}a][{dst}b];[{dst}b]gblur=sigma=14[{dst}g];'
                f'[{dst}a][{dst}g]blend=all_mode=screen:all_opacity=0.35[{dst}]')
    return f'[{src}]null[{dst}]'


def motion_filter(clip: StudioClip, W: int, H: int, fps: int) -> str | None:
    if clip.motion == 'none':
        return None
    frames = max(1, round(clip.length * fps))
    p = f'min(on/{frames},1)'
    z = {'zoom_in': f'1+0.18*{p}', 'zoom_out': f'1.18-0.18*{p}'}.get(clip.motion, '1.15')
    x = {'pan_left': f'(iw-iw/zoom)*(1-{p})', 'pan_right': f'(iw-iw/zoom)*{p}'}.get(
        clip.motion, 'iw/2-(iw/zoom/2)')
    # Upscale first so the slow zoom doesn't stair-step.
    return (f"scale={W * 2}:{H * 2},zoompan=z='{z}':x='{x}':y='ih/2-(ih/zoom/2)'"
            f":d=1:s={W}x{H}:fps={fps}")


class Progress:
    """Maps each FFmpeg stage onto a slice of 0-1."""

    def __init__(self, report: Callable[[float, str], None] | None):
        self.report = report or (lambda p, s: None)
        self.done = 0.0

    def stage(self, weight: float, label: str):
        start = self.done
        self.done += weight
        self.report(start, label)
        return lambda f: self.report(start + weight * max(0.0, min(1.0, f)), label)


def render_studio(sources, music, plan: StudioPlan, destination: Path, overlays=None, audios=None,
                  progress: Callable[[float, str], None] | None = None) -> str:
    ffmpeg, ffprobe = shutil.which('ffmpeg'), shutil.which('ffprobe')
    if not ffmpeg or not ffprobe:
        raise HTTPException(503, 'Media rendering is unavailable.')
    overlays = overlays or []
    audios = audios or []
    track = Progress(progress)

    def run(args, timeout=300, seconds=None, report=None):
        if not report or not seconds:
            return subprocess.run(args, capture_output=True, check=True, timeout=timeout)
        args = args[:1] + ['-progress', 'pipe:1', '-nostats'] + args[1:]
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            for line in proc.stdout:
                if line.startswith('out_time_us='):
                    try:
                        report(int(line.split('=')[1]) / 1e6 / seconds)
                    except ValueError:
                        pass
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
            raise
        if proc.returncode:
            raise subprocess.CalledProcessError(proc.returncode, args, stderr=proc.stderr.read())
        report(1)
        return proc

    base = [ffmpeg, '-v', 'error', '-nostdin', '-y', '-threads', '2', '-filter_threads', '1',
            '-filter_complex_threads', '1']
    enc = ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-pix_fmt', 'yuv420p']

    def probe(path):
        return json.loads(run([ffprobe, '-v', 'error', '-show_streams', '-show_format', '-of', 'json',
                               str(path)], 15).stdout)

    legacy = legacy_matrix(plan)
    fps = plan.fps
    try:
        with tempfile.TemporaryDirectory(prefix='phlio-studio-') as temp:
            work = Path(temp)
            first = next(s for s in probe(sources[0]['path'])['streams'] if s['codec_type'] == 'video')
            W, H = canvas(plan, first)
            image_mode = plan.image_only and sources[0]['mime'].startswith('image/')
            caption = None
            if plan.text:
                caption = work / 'caption.txt'
                caption.write_text(plan.text, encoding='utf-8')

            def clip_graph(i, clip, photo):
                """Video filtergraph for one clip → [v]."""
                pre = []
                if clip.reverse and not photo:
                    pre.append('reverse')
                pre += ['transpose=1'] * clip.turns
                if clip.flip:
                    pre.append('hflip')
                if clip.flip_v:
                    pre.append('vflip')
                if clip.crop:
                    x, y, w, h = clip.crop
                    pre.append(f'crop=iw*{w:.4f}:ih*{h:.4f}:iw*{x:.4f}:ih*{y:.4f}')
                if not photo and clip.hold is None:
                    pre.append(f'setpts=(PTS-STARTPTS)/{clip.speed}')
                pre += color_filters(clip, legacy)
                pre.append('setsar=1')
                chain = f"[0:v]{','.join(pre)}[src];"
                z = clip.zoom
                ox, oy = clip.pan_x, clip.pan_y
                if clip.fit == 'fill':
                    # Same maths as the app preview: scale about the centre,
                    # then shift by pan × half the canvas (crop clamps at edges).
                    z = max(1.0, z)
                    sw, sh = int(W * z) // 2 * 2, int(H * z) // 2 * 2
                    chain += (f'[src]scale={sw}:{sh}:force_original_aspect_ratio=increase,'
                              f"crop={W}:{H}:x='(iw-{W})/2-{ox:.3f}*{W}/2':"
                              f"y='(ih-{H})/2-{oy:.3f}*{H}/2'[framed];")
                else:
                    if plan.background == 'blur':
                        sigma = 6 + plan.blur * 34
                        bg = (f'[bgsrc]scale={W}:{H}:force_original_aspect_ratio=increase,'
                              f'crop={W}:{H},gblur=sigma={sigma:.1f},eq=brightness=-0.04[bg];')
                        chain += '[src]split[bgsrc][fgsrc];' + bg
                    else:
                        chain += (f'[src]null[fgsrc];color=c={plan.background}:s={W}x{H}:r={fps},'
                                  f'format=yuv420p[bg];')
                    fw, fh = int(W * z) // 2 * 2, int(H * z) // 2 * 2
                    chain += (f'[fgsrc]scale={fw}:{fh}:force_original_aspect_ratio=decrease[fg];'
                              f"[bg][fg]overlay=x='(W-w)/2+{ox:.3f}*W/2':y='(H-h)/2+{oy:.3f}*H/2'"
                              f":shortest=1[framed];")
                chain += effect_graph(clip.effect, 'framed', 'fx', W, H) + ';'
                post = []
                mot = motion_filter(clip, W, H, fps)
                if mot:
                    post.append(mot)
                if not image_mode:
                    post.append(f'fps={fps}')
                if caption:
                    escaped = str(caption).replace('\\', '/').replace(':', r'\:')
                    post.append(f"drawtext=textfile='{escaped}':expansion=none:fontcolor=white:"
                                f"fontsize={max(18, W // 22)}:box=1:boxcolor=black@0.5:boxborderw=10:"
                                f"x=(w-tw)/2:y=h-th-h*0.08")
                length = clip.length
                for kind, at in (('in', clip.anim_in), ('out', clip.anim_out)):
                    if at != 'none' and not image_mode:
                        d = min(.5, length / 3)
                        st = 0 if kind == 'in' else length - d
                        color = ':color=white' if at == 'fade_white' else ''
                        post.append(f'fade=t={kind}:st={st:.3f}:d={d:.3f}{color}')
                post += ['format=yuv420p', 'setsar=1']
                if not image_mode:
                    post.append('settb=AVTB')
                return chain + f"[fx]{','.join(post)}[v]"

            # ---- 1. clips ------------------------------------------------------
            segments, lengths = [], []
            weight = .62 if not image_mode else .9
            for i, (source, clip) in enumerate(zip(sources, plan.clips)):
                report = track.stage(weight / len(plan.clips), f'Rendering clip {i + 1} of {len(plan.clips)}')
                photo = source['mime'].startswith('image/')
                path = source['path']
                info = probe(path)
                if not photo and clip.hold is None and clip.end > float(info['format']['duration']) + .15:
                    raise HTTPException(422, 'Trim range exceeds the source video.')
                if clip.hold is not None and not photo:
                    frame = work / f'freeze{i}.png'
                    run(base + ['-ss', f'{clip.start:.3f}', '-i', path, '-frames:v', '1', str(frame)])
                    path, photo = str(frame), True
                graph = clip_graph(i, clip, photo)
                if image_mode:
                    out = destination
                    args = base + ['-i', path]
                    for k, ov in enumerate(overlays):
                        args += ['-i', ov['path']]
                    final = graph.replace('[v]', '[base]')
                    cur = 'base'
                    for k, ov in enumerate(overlays):
                        spec = plan.overlays[k]
                        ow = max(2, int(spec.w * W) // 2 * 2)
                        final += (f';[{k + 1}:v]format=rgba,scale={ow}:-1[o{k}];'
                                  f'[{cur}][o{k}]overlay=x={int(spec.x * W)}:y={int(spec.y * H)}[c{k}]')
                        cur = f'c{k}'
                    final += f';[{cur}]null[out]'
                    q = ['-q:v', '2'] if plan.image_format == 'jpg' else []
                    run(args + ['-filter_complex', final, '-map', '[out]', '-frames:v', '1'] + q + [str(out)])
                    report(1)
                    track.stage(.1, 'Finishing')(1)
                    return 'image'
                length = clip.length
                if photo:
                    args = base + ['-loop', '1', '-framerate', str(fps), '-t', f'{length:.3f}', '-i', path]
                else:
                    args = base + ['-ss', f'{clip.start:.3f}', '-t', f'{clip.end - clip.start:.3f}', '-i', path]
                has_audio = (not photo and not plan.mute_original
                             and any(s['codec_type'] == 'audio' for s in info['streams']))
                if has_audio:
                    afx = []
                    if clip.reverse:
                        afx.append('areverse')
                    afx += [atempo(clip.speed), f'volume={clip.volume}']
                    if clip.fade_audio_in:
                        afx.append(f'afade=t=in:d={clip.fade_audio_in:.2f}')
                    if clip.fade_audio_out:
                        afx.append(f'afade=t=out:st={max(0, length - clip.fade_audio_out):.2f}'
                                   f':d={clip.fade_audio_out:.2f}')
                    afx += ['aresample=48000', 'apad']
                    graph += f";[0:a]{','.join(afx)}[a]"
                else:
                    args += ['-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo']
                    graph += ';[1:a]anull[a]'
                segment = work / f'{i}.mp4'
                run(args + ['-filter_complex', graph, '-map', '[v]', '-map', '[a]', '-t', f'{length:.3f}',
                            '-r', str(fps), '-ac', '2'] + enc + ['-c:a', 'aac', '-b:a', '160k', str(segment)],
                    600, length, report)
                segments.append(segment)
                lengths.append(length)

            # ---- 2. join -------------------------------------------------------
            merged = work / 'merged.mp4'
            total = plan.total
            report = track.stage(.14, 'Joining clips')
            if len(segments) == 1:
                shutil.copyfile(segments[0], merged)
                report(1)
            else:
                args = base.copy()
                for segment in segments:
                    args += ['-i', str(segment)]
                parts = []
                v, a = '0:v', '0:a'
                acc = lengths[0]
                legacy_t = plan.transition if plan.transition != 'none' else None
                for i in range(1, len(segments)):
                    prev = plan.clips[i - 1]
                    kind = prev.transition if prev.transition != 'none' else legacy_t
                    if kind:
                        d = overlap(prev, plan.clips[i]) if prev.transition != 'none' else min(
                            .4, lengths[i - 1] / 3, lengths[i] / 3)
                        parts += [f'[{v}][{i}:v]xfade=transition={kind}:duration={d:.3f}:offset={acc - d:.3f}[v{i}]',
                                  f'[{a}][{i}:a]acrossfade=d={d:.3f}[a{i}]']
                        acc += lengths[i] - d
                    else:
                        parts.append(f'[{v}][{a}][{i}:v][{i}:a]concat=n=2:v=1:a=1[v{i}][a{i}]')
                        acc += lengths[i]
                    v, a = f'v{i}', f'a{i}'
                total = acc
                run(args + ['-filter_complex', ';'.join(parts), '-map', f'[{v}]', '-map', f'[{a}]'] + enc
                    + ['-c:a', 'aac', '-b:a', '160k', str(merged)], 900, total, report)

            # ---- 3. overlays + audio ----------------------------------------------
            items = list(audios)
            if music:  # legacy single music track
                items.append(dict(path=music['path'], spec=StudioAudio(
                    file_id=plan.music_id, volume=plan.music_volume, loop=True)))
            report = track.stage(1 - track.done, 'Adding text, stickers and sound')
            if not overlays and not items:
                shutil.copyfile(merged, destination)
                report(1)
                return 'video'
            args = base + ['-i', str(merged)]
            graph, cur, n = [], '0:v', 1
            for k, ov in enumerate(overlays):
                spec = plan.overlays[k]
                args += ['-loop', '1', '-t', f'{total:.3f}', '-i', ov['path']]
                ow = max(2, int(spec.w * W) // 2 * 2)
                s, e = max(0.0, spec.start), min(total, spec.end)
                d = min(.35, max(.05, (e - s) / 4))
                chain = f'[{n}:v]format=rgba,scale={ow}:-1'
                if spec.anim_in == 'fade':
                    chain += f',fade=t=in:st={s:.3f}:d={d:.3f}:alpha=1'
                if spec.anim_out == 'fade':
                    chain += f',fade=t=out:st={max(s, e - d):.3f}:d={d:.3f}:alpha=1'
                graph.append(chain + f'[o{k}]')
                X, Y = int(spec.x * W), int(spec.y * H)
                ramp = f'(1-min(max(t-{s:.3f},0)/0.35,1))'
                x = f'{X}+{ramp}*{W * .12:.0f}' if spec.anim_in == 'slide_left' else str(X)
                y = f'{Y}+{ramp}*{H * .06:.0f}' if spec.anim_in == 'slide_up' else str(Y)
                graph.append(f"[{cur}][o{k}]overlay=x='{x}':y='{y}':enable='between(t,{s:.3f},{e:.3f})'[c{k}]")
                cur = f'c{k}'
                n += 1
            mixes = ['[0:a]anull[base]']
            labels = ['[base]']
            for j, item in enumerate(items):
                spec: StudioAudio = item['spec']
                if spec.loop:
                    args += ['-stream_loop', '-1']
                args += ['-i', item['path']]
                f = [f'atrim=start={spec.start:.3f}' + (f':end={spec.end:.3f}' if spec.end else '')]
                f += ['asetpts=PTS-STARTPTS', f'volume={spec.volume}']
                room = max(.3, total - spec.at)
                if spec.end:
                    room = min(room, (spec.end - spec.start))
                f.append(f'atrim=end={room:.3f}')
                if spec.fade_in:
                    f.append(f'afade=t=in:d={spec.fade_in:.2f}')
                if spec.fade_out:
                    f.append(f'afade=t=out:st={max(0, room - spec.fade_out):.2f}:d={spec.fade_out:.2f}')
                delay = int(spec.at * 1000)
                f += [f'adelay={delay}|{delay}', 'aresample=48000']
                mixes.append(f'[{n}:a]{",".join(f)}[m{j}]')
                labels.append(f'[m{j}]')
                n += 1
            if len(labels) > 1:
                mixes.append(''.join(labels) + f'amix=inputs={len(labels)}:duration=first:normalize=0,'
                             'alimiter=limit=0.95[aout]')
            else:
                mixes.append('[base]anull[aout]')
            vmap = f'[{cur}]' if overlays else '0:v'
            if overlays:
                graph.append(f'[{cur}]format=yuv420p[vout]')
                vmap = '[vout]'
            full = ';'.join(graph + mixes)
            vcodec = enc if overlays else ['-c:v', 'copy']
            run(args + ['-filter_complex', full, '-map', vmap, '-map', '[aout]', '-t', f'{total:.3f}']
                + vcodec + ['-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', str(destination)],
                900, total, report)
            return 'video'
    except HTTPException:
        raise
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or b'')
        if isinstance(detail, bytes):
            detail = detail.decode(errors='replace')
        import logging
        logging.getLogger('phlio.studio').warning('FFmpeg failed: %s', detail[-2000:])
        raise HTTPException(422, 'Could not render this project. Check the clips and try a shorter export.') from exc
    except (OSError, ValueError, KeyError, StopIteration, subprocess.SubprocessError) as exc:
        raise HTTPException(422, 'Could not render this project. Check the clips and try a shorter export.') from exc


# -- previews for the timeline ------------------------------------------------------

def filmstrip(path: str, mime: str, destination: Path, frames: int = 12, height: int = 96):
    """Horizontal JPEG strip of evenly spaced frames (one per tile)."""
    ffmpeg, ffprobe = shutil.which('ffmpeg'), shutil.which('ffprobe')
    if not ffmpeg:
        raise HTTPException(503, 'Media previews are unavailable.')
    if mime.startswith('image/'):
        subprocess.run([ffmpeg, '-v', 'error', '-y', '-i', path, '-vf',
                        f'scale=-2:{height},crop=min(iw\\,{height * 3 // 4}):{height}', '-frames:v', '1',
                        '-q:v', '4', str(destination)], check=True, capture_output=True, timeout=30)
        return 1
    info = json.loads(subprocess.run([ffprobe, '-v', 'error', '-show_format', '-of', 'json', path],
                                     check=True, capture_output=True, timeout=15).stdout)
    duration = max(.1, float(info['format']['duration']))
    rate = frames / duration
    tile = height * 3 // 4
    subprocess.run([ffmpeg, '-v', 'error', '-y', '-i', path, '-vf',
                    f'fps={rate:.5f},scale={tile}:{height}:force_original_aspect_ratio=increase,'
                    f'crop={tile}:{height},tile={frames}x1', '-frames:v', '1', '-q:v', '5', str(destination)],
                   check=True, capture_output=True, timeout=120)
    return frames


def waveform(path: str, points: int = 200) -> dict:
    import numpy as np
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise HTTPException(503, 'Media previews are unavailable.')
    raw = subprocess.run([ffmpeg, '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', '4000', '-f', 's16le', '-'],
                         check=True, capture_output=True, timeout=120).stdout
    x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768
    duration = len(x) / 4000
    if not len(x):
        return dict(duration=0, peaks=[])
    chunks = np.array_split(np.abs(x), min(points, len(x)))
    peaks = np.array([float(c.max()) for c in chunks])
    top = float(np.percentile(peaks, 99)) or 1.0
    return dict(duration=round(duration, 3), peaks=[round(float(min(1, v / top)), 3) for v in peaks])
